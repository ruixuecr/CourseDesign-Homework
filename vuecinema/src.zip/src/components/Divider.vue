<template>
    <div class="divider-box"></div>
</template>
<script>
export default {
    name: 'Divider'
}
</script>

<style lang="scss">
.divider-box {
    margin: 20px 0;
    width: 100%;
    height: 1px;
    background-color: #37383dc4;
}
</style>
