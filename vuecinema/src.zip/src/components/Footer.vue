<template>
  <div>
    <span>©8102 · 持续输出中... Copyright©瑞雪电影院 ALL Rights Reserved</span>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped lang="scss"></style>
