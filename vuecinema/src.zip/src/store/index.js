import Vuex from 'vuex'
const store = new Vuex.Store({})

export default store