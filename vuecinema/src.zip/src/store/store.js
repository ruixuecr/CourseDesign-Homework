import store from './index.js'
import './movie.js'

export default store
